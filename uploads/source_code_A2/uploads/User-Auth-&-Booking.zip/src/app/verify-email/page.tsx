"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function VerifyEmailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState<"verifying" | "success" | "error">("verifying");
  const [message, setMessage] = useState("Đang xác thực email của bạn...");

  useEffect(() => {
    const verifyEmail = async () => {
      if (!token) {
        setStatus("error");
        setMessage("Token không hợp lệ. Vui lòng kiểm tra lại link xác thực.");
        return;
      }

      try {
        const response = await fetch(`/api/verify-email?token=${token}`);

        if (response.redirected) {
          // API redirect thành công, chuyển hướng đến trang thành công
          router.push(response.url);
          return;
        }

        const data = await response.json();

        if (!response.ok) {
          setStatus("error");
          setMessage(data.message || "Đã xảy ra lỗi khi xác thực email.");
        } else {
          setStatus("success");
          setMessage("Email đã được xác thực thành công!");

          // Chuyển hướng đến trang thành công sau 2 giây
          setTimeout(() => {
            router.push("/email-verified");
          }, 2000);
        }
      } catch (error) {
        console.error("Verification error:", error);
        setStatus("error");
        setMessage("Đã xảy ra lỗi khi xác thực email. Vui lòng thử lại sau.");
      }
    };

    verifyEmail();
  }, [token, router]);

  return (
    <div className="container flex items-center justify-center min-h-[calc(100vh-180px)]">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <CardTitle>Xác thực Email</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          {status === "verifying" && (
            <div className="flex flex-col items-center">
              <Loader2 className="h-16 w-16 animate-spin text-green-700 mb-4" />
              <p>{message}</p>
            </div>
          )}

          {status === "success" && (
            <div className="text-green-700">
              <p>{message}</p>
              <p className="text-sm mt-2">Đang chuyển hướng...</p>
            </div>
          )}

          {status === "error" && (
            <div className="text-red-600">
              <p>{message}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
