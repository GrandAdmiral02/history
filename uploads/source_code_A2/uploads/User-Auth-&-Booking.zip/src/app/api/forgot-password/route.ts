import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import crypto from "crypto";
import { z } from "zod";

// Schema validation cho dữ liệu email
const EmailSchema = z.object({
  email: z.string().email("Email không hợp lệ"),
});

// Tạo token đặt lại mật khẩu
const generateResetToken = async (email: string) => {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 giờ

  const existingToken = await prisma.verificationToken.findFirst({
    where: {
      identifier: email,
      // Thêm điều kiện để phân biệt với token xác thực email
      token: {
        startsWith: "reset-"
      }
    }
  });

  if (existingToken) {
    return prisma.verificationToken.update({
      where: {
        identifier_token: {
          identifier: email,
          token: existingToken.token
        }
      },
      data: {
        token: `reset-${token}`,
        expires
      }
    });
  }

  return prisma.verificationToken.create({
    data: {
      identifier: email,
      token: `reset-${token}`,
      expires
    }
  });
};

// Hàm giả lập gửi email (trong môi trường production sẽ dùng dịch vụ email thực tế)
const sendPasswordResetEmail = async (email: string, token: string) => {
  const resetUrl = `${process.env.NEXTAUTH_URL}/reset-password?token=${token}`;

  console.log(`
    ===============================
    Email đặt lại mật khẩu sẽ được gửi đến: ${email}
    Link đặt lại mật khẩu: ${resetUrl}
    (Link có hiệu lực trong 24 giờ)
    ===============================
  `);

  // Trong môi trường thực tế, chúng ta sẽ dùng sendgrid, mailchimp, v.v.
  return true;
};

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Kiểm tra dữ liệu với schema
    const { email } = EmailSchema.parse(body);

    // Kiểm tra email có tồn tại trong cơ sở dữ liệu không
    const user = await prisma.user.findUnique({
      where: { email },
    });

    // Luôn trả về phản hồi thành công, ngay cả khi email không tồn tại
    // Để tránh tiết lộ thông tin người dùng thông qua phản hồi API

    if (user) {
      // Tạo token và gửi email
      const resetToken = await generateResetToken(email);
      await sendPasswordResetEmail(email, resetToken.token);
    }

    return NextResponse.json({
      success: true,
      message: "Nếu email tồn tại, một liên kết đặt lại mật khẩu đã được gửi đến địa chỉ email của bạn.",
    });

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      );
    }

    console.error("Forgot password error:", error);
    return NextResponse.json(
      { success: false, error: "Đã xảy ra lỗi khi xử lý yêu cầu" },
      { status: 500 }
    );
  }
}
